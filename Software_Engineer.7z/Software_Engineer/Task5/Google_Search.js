// Run below 2 code lines in the terminal:

// npm init -y
// npm i --save puppeteer

const puppeteer = require('puppeteer');

function main() {
    automateSearch();
}

async function automateSearch() {
    const browser = await puppeteer.launch({headless: false});
    const page = await browser.newPage();
    await page.setViewport({width: 1288, height: 880 });
    await page.goto('https://google.com');
    await page.type('.gLFyf.gsfi', 'Robot Process Automation');
    await page.click('input.gNO89b');
}

main()